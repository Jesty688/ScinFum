<?php 

require_once('./func.php');
$dsn = 'mysql:host=127.0.0.1;dbname=test;charset=utf8;port=3306';
$user ='root';
$pass = 'su1980root';

$pdo = new PDO($dsn,$user,$pass);

$param = $_POST['param'] ?? 0;
$comment_content = $_POST['comment_content'] ?? '';
$datarry = [];


switch ($param) {
	case 1:
		$sql = "select article_comment from scin_article where article_id = $param";

		array_push($datarry, ($pdo -> query($sql) -> fetch(PDO::FETCH_ASSOC)));

		$sql = "SELECT comment_userid,comment_content from scin_article join scin_comment on scin_article.article_id = scin_comment.comment_id;";
		array_push($datarry, ($pdo -> query($sql) -> fetchAll(PDO::FETCH_ASSOC)));

		echo(json_encode($datarry));
		
		break;
	case 2:
		//若传入的参数是2 表示需要进行添加评论(insert into) --先不判断二级回复
		$comment_content = RemoveXSS($comment_content);
		//这里应该需要过滤一下用户输入的文本内容 防止xss
		$sql = "INSERT INTO scin_comment(comment_id,comment_userid,comment_content)";
		$sql .= "VALUES(
			(SELECT article_id from scin_article),
			(SELECT user_id from scin_user),
			'$comment_content')";
			
		//echo ($sql);
		if($pdo -> exec($sql)){
			//执行成功
			echo json_encode(['code' => 1,'content' => $comment_content]);
		}else{
			//执行失败
			echo json_encode(['code' => -1,'error_msg' => '评论失败']);

		}
		break;
	default:
		# code...
		break;
}



