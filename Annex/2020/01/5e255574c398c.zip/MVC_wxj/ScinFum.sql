--创建数据表

CREATE TABLE scin_user(
  user_id INT(11) NOT NULL AUTO_INCREMENT  PRIMARY KEY,
  user_name varchar(8) not NULL

)charset=utf8;


CREATE TABLE scin_article(
  article_id INT(11) NOT NULL AUTO_INCREMENT  PRIMARY KEY,
  article_comment text
)charset=utf8;
CREATE TABLE scin_comment(
  comment_id INT(11) NOT NULL comment"需要和文章表连接这里的id等于文章id", 
  comment_pid INT(11) NOT NULL AUTO_INCREMENT  PRIMARY KEY,
  comment_userid int not null,
  comment_content text
)charset=utf8;

CREATE TABLE scin_reply(
  reply_id INT(11) NOT NULL AUTO_INCREMENT  PRIMARY KEY,
  areply_comment text
)charset=utf8;
--插入测试数据
INSERT INTO scin_user (user_name) VALUES ('Champs');
INSERT INTO scin_article (article_comment) VALUES (
'这里简单说一下，由于可以指定插入到talbe2中的列，以及可以通过相对较复杂的查询语句进行数据源获取，可能使用起来会更加的灵活一些，但我们也必须注意，我们在指定目标表的列时，一定要将所有非空列都填上，否则将无法进行数据插入，还有一点比较容易出错的地方就是，当我们写成如下简写格式：方式3.2、  INSERT INTO t2 SELECT id, name, address FROM t1
此时，我们如果略掉了目标表的列的话，则默认会对目标表的全部列进行数据插入，且SELECT后面的列的顺序 必须和目标表中的列的定义顺序完全一致 才能完成正确的数据插入，这是一个很容易被忽略的地方，值得注意。'
);
--连表插入 示例
INSERT INTO scin_comment(comment_id,comment_userid,comment_content)VALUES(
	(SELECT article_id from scin_article),
	(SELECT user_id from scin_user),
	'测试评论内容'
);
--连表查询 --示例 #点击某个文章页面显示文章内容 显示评论添加data-userid当前这个评论的userid 评论内容
SELECT comment_userid,comment_content from scin_article join scin_comment on scin_article.article_id = scin_comment.comment_id;



--实现父评论下的子评论




--思路无限极
	--一个文章可以有多个评论
	--一个评论可以有多个子评论
	--一个子评论可以有多个子子评论
	--...无限循环
--怎么实现???

--tttttt
	--用到的数据表：
			--scin_user 	用户表
			--scin_article  文章表
			#因为需要实现无限极评论 新建2个表
			--scin_comment 评论表   OK
				#scin_comment.comment_id = scin_article.article_id  获取对应的文章表中的对应评论
			--scin_reply   评论回复表  
				#scin_reply.reply_id = scin_comment.comment_pid


