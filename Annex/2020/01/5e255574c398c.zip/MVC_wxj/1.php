<?php 

$a = '<h1>很大的字<h1>';
echo htmlspecialchars($a);